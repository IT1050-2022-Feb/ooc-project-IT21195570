#include "stdafx.h"
#include "RegisteredUser.h"
#include <cstring>
#include <iostream>
using namespace std;


RegisteredUser::RegisteredUser()
{
	strcpy_s(u_Name, "Amal");
	u_Phone = 0712363276;
	strcpy_s(u_Email, "amal@gmail.com");
	strcpy_s(u_ID, "U001");
	strcpy_s(u_Password, "1234A");
	Payment *pay;
}

RegisteredUser::RegisteredUser(char uName[], int uPhone, char uMail[], char uID[], char uPass[])
{
	strcpy_s(u_Name, uName);
	u_Phone = uPhone;
	strcpy_s(u_Email, uMail);
	strcpy_s(u_ID, uID);
	strcpy_s(u_Password, uPass);
}

void RegisteredUser::makePayment(Payment * pay)
{
}

void RegisteredUser::DisplayUserDetails()
{
	cout << "User Name : " << u_Name << endl
		<< "User Phone Number : " << u_Phone << endl
		<< "User Email : " << u_Email << endl
		<< "User ID : " << u_ID << endl
		<< "User Password : " << u_Password << endl;
}


RegisteredUser::~RegisteredUser()
{
	cout << "Destructed" << endl;
}
