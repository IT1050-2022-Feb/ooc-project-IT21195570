#pragma once
#include "Payment.h"
#define SIZE 2
class RegisteredUser
{
private: 
	char u_Name[20];
	int u_Phone;
	char u_Email[20];
	char u_ID[4];
	char u_Password[15];
	Payment *pay[SIZE];

public:
	RegisteredUser();
	RegisteredUser(char uName[], int uPhone, char uMail[], char uID[], char uPass[]);
	void makePayment(Payment *pay);
	void DisplayUserDetails();
	~RegisteredUser();
};

