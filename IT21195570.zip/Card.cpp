#include "stdafx.h"
#include "Card.h"
#include "Payment.h"
#include <cstring>
#include <iostream>
using namespace std;


Card::Card()
{
	strcpy_s(cardType,"Credit Card");
	cardNumber = 4261398;
	cvcNumber = 345;
	strcpy_s(expiryMonth, "July");
	expiryYear = 2028;
}

Card::Card(char cType[], int cNo, int cvcNo, char exM[], int exY)
{
	strcpy_s(cardType, cType);
	cardNumber = cNo;
	cvcNumber = cvcNo;
	strcpy_s(expiryMonth, exM);
	expiryYear = exY;
}

void Card::validPayment()
{
}

void Card::DoTransaction()
{
}

void Card::DisplayCardDetails()
{
	cout << "Card Type : " << cardType << endl
		<< "Card Number : " << cardNumber << endl
		<< "CVC Number : " << cvcNumber << endl
		<< "Expiry Month : " << expiryMonth << endl
		<< "Expiry Year : " << expiryYear << endl;
}


Card::~Card()
{
	cout << "Destructed" << endl;
}
