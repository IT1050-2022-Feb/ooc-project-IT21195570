#pragma once
#include  "Payment.h"
class Card: public Payment
{
protected:
	char cardType[20];
	int cardNumber;
	int cvcNumber;
	char expiryMonth[10];
	int expiryYear;

public:
	Card();
	Card(char cType[], int cNo, int cvcNo, char exM[], int exY);
	void validPayment();
	void DoTransaction();
	void DisplayCardDetails();
	~Card();
};

